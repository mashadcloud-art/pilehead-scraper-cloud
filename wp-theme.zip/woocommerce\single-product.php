<?php
/**
 * Single Product Template — Redesigned with Zoom & PDF Viewer (Compact Docs)
 * Pilehead Store · UAE
 * Version: 2.1.0 — WhatsApp Price Button (No Price / Zero Price)
 */

if (!defined('ABSPATH')) exit;
get_header('shop');
wp_enqueue_script('wc-add-to-cart');

if (have_posts()) {
    while (have_posts()) {
        the_post();
        global $product;
        if (empty($product) || !$product->is_visible()) return;

        $product_id          = $product->get_id();
        $average_rating      = $product->get_average_rating();
        $rating_count        = $product->get_rating_count();
        $currency            = get_woocommerce_currency_symbol();
        $price               = (float) $product->get_price();
        $regular_price       = (float) $product->get_regular_price();
        $discount_percentage = ($product->is_on_sale() && $regular_price > 0)
            ? round((($regular_price - $price) / $regular_price) * 100) : 0;

        $datasheet_url = get_post_meta($product_id, 'datasheet_url', true) ?: $product->get_attribute('datasheet_url');
        $sds_url       = get_post_meta($product_id, 'sds_url', true) ?: get_post_meta($product_id, 'safety_datasheet_url', true) ?: $product->get_attribute('sds_url');
        $ms_url        = get_post_meta($product_id, 'ms_url', true) ?: get_post_meta($product_id, 'method_statement_url', true) ?: $product->get_attribute('ms_url');
        $has_downloads = !empty($sds_url) || !empty($ms_url) || !empty($datasheet_url);

        $brand = '';
        $brand = $product->get_attribute('pa_brand');
        if (empty($brand)) {
            $brand_terms = get_the_terms($product_id, 'product_brand');
            if ($brand_terms && !is_wp_error($brand_terms)) {
                $brand = $brand_terms[0]->name;
            }
        }
        if (empty($brand)) {
            $brand = get_post_meta($product_id, '_brand', true);
        }
        if (empty($brand)) {
            $title_parts = explode(' ', $product->get_name());
            $brand = $title_parts[0];
        }

        $post_thumbnail_id = $product->get_image_id();
        $main_img_alt = '';
        if ($post_thumbnail_id) {
            $main_img_alt = get_post_meta($post_thumbnail_id, '_wp_attachment_image_alt', true);
        }
        if (empty($main_img_alt)) {
            $main_img_alt = $product->get_name() . ' UAE';
        }

        $related_ids = wc_get_related_products($product_id, 15);

        $wa_number  = '971547656789';
        $wa_message = urlencode('Hello PileHead, I would like to get the price for: ' . $product->get_name() . ' (SKU: ' . ($product->get_sku() ?: 'N/A') . ')');
        $wa_url     = 'https://wa.me/' . $wa_number . '?text=' . $wa_message;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<?php
wp_enqueue_style('ph-single-product', get_template_directory_uri() . '/woocommerce/assets/css/ph-single-product.css', array(), '2.1.4');
wp_enqueue_style('ph-quote-request', get_template_directory_uri() . '/woocommerce/assets/css/ph-quote-request.css', array(), '1.2.2');
wp_enqueue_script('ph-single-product', get_template_directory_uri() . '/woocommerce/assets/js/ph-single-product.js', array('jquery'), '2.3.1', true);
wp_head();
?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<script>
window.phProductPrice  = <?php echo json_encode($price); ?>;
window.phAjaxUrl       = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
window.phNonce         = '<?php echo wp_create_nonce('wc-add-to-cart'); ?>';
window.phCheckoutUrl   = '<?php echo esc_url(wc_get_checkout_url()); ?>';
window.phProductId     = <?php echo $product_id; ?>;
</script>

<!-- Zoom overlay -->
<div class="ph-zoom-overlay" id="zoomOverlay" onclick="closeZoom(event)">
    <span class="ph-zoom-close" onclick="closeZoom(event)">×</span>
    <div class="ph-zoom-container" onclick="event.stopPropagation()">
        <img src="" alt="Product Zoom" class="ph-zoom-image" id="zoomImage">
    </div>
    <div class="ph-zoom-hint">Click outside to close · Press ESC</div>
</div>

<div class="ph-page">

    <nav class="ph-breadcrumb">
        <?php woocommerce_breadcrumb(); ?>
    </nav>

    <!-- ══ 3-Column product grid ══ -->
    <div class="ph-product-grid">

        <!-- COL 1: Gallery -->
        <div class="ph-gallery">
            <div class="ph-main-image" onclick="openZoom()">
                <?php if ($post_thumbnail_id): ?>
                    <?php $full_src = wp_get_attachment_image_url($post_thumbnail_id, 'full'); ?>
                    <img src="<?php echo esc_url($full_src); ?>" alt="<?php echo esc_attr($main_img_alt); ?>" class="ph-main-image-img" loading="eager" id="mainProductImage">
                <?php else: ?>
                    <img src="<?php echo wc_placeholder_img_src(); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="ph-main-image-img" id="mainProductImage">
                <?php endif; ?>
                <?php if ($product->is_featured()): ?>
                    <div class="ph-badge-featured">Best Seller</div>
                <?php endif; ?>
                <?php if ($discount_percentage > 0): ?>
                    <div class="ph-badge-sale">−<?php echo $discount_percentage; ?>%</div>
                <?php endif; ?>
            </div>
            <div class="ph-thumbs">
                <?php
                $attachment_ids = $product->get_gallery_image_ids();
                if ($post_thumbnail_id) {
                    $thumb_src = wp_get_attachment_image_url($post_thumbnail_id, 'woocommerce_gallery_thumbnail');
                    $full_src  = wp_get_attachment_image_url($post_thumbnail_id, 'full');
                    $thumb_alt = get_post_meta($post_thumbnail_id, '_wp_attachment_image_alt', true) ?: $product->get_name();
                    echo '<img src="' . esc_url($thumb_src) . '" data-full="' . esc_url($full_src) . '" class="ph-thumb active" alt="' . esc_attr($thumb_alt) . '">';
                }
                $g_counter = 2;
                foreach ($attachment_ids as $att_id) {
                    $thumb_src = wp_get_attachment_image_url($att_id, 'woocommerce_gallery_thumbnail');
                    $full_src  = wp_get_attachment_image_url($att_id, 'full');
                    $g_alt     = get_post_meta($att_id, '_wp_attachment_image_alt', true) ?: ($product->get_name() . ' - View ' . $g_counter);
                    echo '<img src="' . esc_url($thumb_src) . '" data-full="' . esc_url($full_src) . '" class="ph-thumb" alt="' . esc_attr($g_alt) . '">';
                    $g_counter++;
                }
                ?>
            </div>
        </div>

        <!-- COL 2: Product Info -->
        <div class="ph-info">
            <?php
            if ($brand) {
                $brand_link = get_term_link(sanitize_title($brand), 'product_brand');
                if (!is_wp_error($brand_link)) {
                    echo '<a href="' . esc_url($brand_link) . '" class="ph-brand">' . esc_html($brand) . '</a>';
                } else {
                    echo '<span class="ph-brand">' . esc_html($brand) . '</span>';
                }
            }
            ?>

            <h1 class="ph-title"><?php echo esc_html($product->get_name()); ?></h1>
            <div class="ph-sku">SKU: <?php echo esc_html($product->get_sku() ?: '—'); ?></div>

            <div class="ph-rating-row">
                <span class="ph-stars">
                    <?php
                    $rating = $average_rating ?: 4.7;
                    for ($i = 1; $i <= 5; $i++) {
                        echo $i <= round($rating) ? '★' : '☆';
                    }
                    ?>
                </span>
                <span class="ph-rating-num"><?php echo number_format($rating, 1); ?></span>
                <span class="ph-rating-count">(<?php echo $rating_count ?: 8; ?> reviews)</span>
            </div>

            <?php if ($price > 0): ?>
            <div class="ph-price-block">
                <div class="ph-price-main">
                    <img src="https://www.pilehead.com/wp-content/uploads/2025/10/uae-dirham-symbol.svg" alt="AED" class="ph-currency-icon">
                    <span class="ph-price-num" id="ph-main-price"><?php echo number_format($price, 2); ?></span>
                    <span class="ph-vat-tag">Incl. VAT</span>
                </div>
                <?php if ($regular_price > $price): ?>
                <div class="ph-price-compare">
                    <span class="ph-price-old"><?php echo $currency . ' ' . number_format($regular_price, 2); ?></span>
                    <span class="ph-discount-pill"><?php echo $discount_percentage; ?>% OFF</span>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($product->get_short_description()): ?>
            <div class="ph-highlights">
                <div class="ph-highlights-label">Highlights</div>
                <?php echo wp_kses_post($product->get_short_description()); ?>
            </div>
            <?php endif; ?>

            <?php if ($product->is_type('variable')): ?>
            <?php
            $attributes           = $product->get_variation_attributes();
            $available_variations = $product->get_available_variations();
            ?>
            <div class="ph-options-block">
                <div class="ph-options-title">Select Options</div>
                <?php foreach ($attributes as $attribute_name => $options): ?>
                <?php $attribute_label = wc_attribute_label($attribute_name); ?>
                <div class="ph-var-row">
                    <label class="ph-var-label"><?php echo esc_html($attribute_label); ?></label>
                    <select class="ph-select variation-select"
                            name="attribute_<?php echo esc_attr(sanitize_title($attribute_name)); ?>"
                            data-attribute_name="attribute_<?php echo esc_attr(sanitize_title($attribute_name)); ?>">
                        <option value="">Choose <?php echo esc_html($attribute_label); ?></option>
                        <?php foreach ($options as $option): ?>
                        <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($price > 0): ?>
            <div class="ph-qty-cart-row">
                <div class="ph-qty-wrap">
                    <button type="button" class="ph-qty-btn" id="ph-qty-minus">−</button>
                    <input type="number" class="ph-qty-input" id="ph-qty-input" value="1" min="1" max="99">
                    <button type="button" class="ph-qty-btn" id="ph-qty-plus">+</button>
                </div>
                <button type="button" class="ph-atc-btn" id="ph-atc-btn"
                    data-product-id="<?php echo $product_id; ?>"
                    data-product-type="<?php echo esc_attr($product->get_type()); ?>"
                    <?php echo !$product->is_in_stock() ? 'disabled' : ''; ?>>
                    <span><?php echo $product->is_in_stock() ? 'Add to Cart' : 'Out of Stock'; ?></span>
                </button>
            </div>
            <?php endif; ?>

            <div class="ph-delivery-options">
                <div class="ph-delivery-card selected">
                    <div class="ph-delivery-header">
                        <span style="font-weight:bold;font-size:14px;color:#0A0A0A;">⚡ Superfast</span>
                        <button class="ph-delivery-info-btn" onclick="openDeliveryModal('superfast')" title="Delivery details">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        </button>
                    </div>
                    <div class="ph-delivery-body">
                        <div><div class="ph-delivery-label">Same Day</div><div class="ph-delivery-sub">Within 3 hours</div></div>
                        <div class="ph-delivery-price">AED 60</div>
                    </div>
                </div>
                <div class="ph-delivery-card">
                    <div class="ph-delivery-header">
                        <span style="font-weight:bold;font-size:14px;color:#0A0A0A;">🚚 Standard</span>
                        <button class="ph-delivery-info-btn" onclick="openDeliveryModal('stander')" title="Delivery details">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        </button>
                    </div>
                    <div class="ph-delivery-body">
                        <div><div class="ph-delivery-label">Next Day</div><div class="ph-delivery-sub">Before 10 PM</div></div>
                        <div class="ph-delivery-price">FREE</div>
                    </div>
                </div>
            </div>

            <div class="ph-free-contact">
                <div class="ph-free-info">
                    <div class="ph-free-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <div class="ph-free-text">
                        <strong>Free UAE Delivery on orders over AED 200</strong>
                        <span>Dispatched from Dubai · Covers all 7 Emirates</span>
                    </div>
                </div>
                <div class="ph-contact-btns">
                    <a href="https://wa.me/971547656789" class="ph-contact-btn" target="_blank" title="WhatsApp">
                        <svg viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                    </a>
                    <a href="tel:+971547656789" class="ph-contact-btn" title="Call">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    </a>
                </div>
            </div>

            <?php if ($has_downloads): ?>
            <meta itemprop="associatedMedia" content="<?php echo esc_attr($brand); ?> <?php echo esc_attr($product->get_name()); ?> Technical Datasheet PDF">
            <?php if ($sds_url): ?><meta itemprop="associatedMedia" content="<?php echo esc_attr($brand); ?> <?php echo esc_attr($product->get_name()); ?> Safety Data Sheet"><?php endif; ?>
            <?php if ($ms_url): ?><meta itemprop="associatedMedia" content="<?php echo esc_attr($brand); ?> <?php echo esc_attr($product->get_name()); ?> Method Statement"><?php endif; ?>

            <div class="ph-assets-section">
                <?php
                $documents  = array();
                $doc_labels = array();
                if ($datasheet_url) {
                    $documents[]  = array('url' => $datasheet_url, 'title' => 'Technical Datasheet', 'type' => 'datasheet');
                    $doc_labels[] = 'Datasheet';
                }
                if ($sds_url) {
                    $documents[]  = array('url' => $sds_url, 'title' => 'Safety Data Sheet', 'type' => 'sds');
                    $doc_labels[] = 'SDS';
                }
                if ($ms_url) {
                    $documents[]  = array('url' => $ms_url, 'title' => 'Method Statement', 'type' => 'method');
                    $doc_labels[] = 'Method';
                }
                if (!empty($documents)):
                    $docs_json = json_encode($documents, JSON_HEX_QUOT | JSON_HEX_APOS);
                ?>
                <div class="ph-asset-module"
                     onclick='openPdfPreview(<?php echo $docs_json; ?>, "<?php echo esc_js($product->get_name()); ?>")'
                     title="Preview Technical Documents"
                     aria-label="View Technical Documents: <?php echo esc_attr($product->get_name()); ?>">
                    <div class="ph-icon-shield">
                        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                    </div>
                    <div class="ph-content">
                        <span class="ph-asset-title"><?php echo esc_html($product->get_name()); ?></span>
                        <span class="ph-asset-subtitle">Documentation: <?php echo esc_html(implode(', ', $doc_labels)); ?></span>
                    </div>
                    <div class="ph-action-box">
                        <svg class="ph-arrow-svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="ph-trust">
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg><span>100% Genuine</span></div>
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg><span>Easy Returns</span></div>
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg><span>Secure Checkout</span></div>
            </div>
        </div>

        <!-- COL 3: Buy Box -->
        <div class="ph-buybox">
            <div>
                <?php if ($price > 0): ?>
                <div class="ph-buybox-price-label">Total Price</div>
                <div class="ph-buybox-total">
                    <img src="https://www.pilehead.com/wp-content/uploads/2025/10/uae-dirham-symbol.svg" alt="AED">
                    <span id="ph-buybox-price"><?php echo number_format($price, 2); ?></span>
                </div>
                <?php if ($product->is_on_sale()): ?>
                <div style="font-size:12px;color:var(--green);margin-top:4px;font-weight:600;">
                    You save <?php echo $currency; ?> <?php echo number_format($regular_price - $price, 2); ?> (<?php echo $discount_percentage; ?>% OFF)
                </div>
                <?php endif; ?>
                <?php else: ?>
                <div class="ph-buybox-price-label">Price on Request</div>
                <div style="font-size:15px;font-weight:600;color:var(--stone);margin-top:4px;">Contact us for pricing</div>
                <?php endif; ?>
            </div>

            <div class="ph-buybox-divider"></div>

            <?php if ($price > 0): ?>
            <div>
                <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--stone);margin-bottom:10px;">Quantity</div>
                <div class="ph-sidebar-qty">
                    <button class="ph-sidebar-qty-btn" id="ph-sidebar-qty-minus">−</button>
                    <input type="number" class="ph-sidebar-qty-input" id="ph-sidebar-qty-input" value="1" min="1" max="99">
                    <button class="ph-sidebar-qty-btn" id="ph-sidebar-qty-plus">+</button>
                </div>
            </div>

            <button class="ph-sidebar-atc" id="ph-sidebar-atc"
                data-product-id="<?php echo $product_id; ?>"
                <?php echo !$product->is_in_stock() ? 'disabled' : ''; ?>>
                <?php echo $product->is_in_stock() ? 'Add to Cart' : 'Out of Stock'; ?>
            </button>

            <button class="ph-sidebar-buy" id="ph-sidebar-buy"
                data-product-id="<?php echo $product_id; ?>">
                Buy Now
            </button>

            <div class="ph-trust">
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg><span>100% Genuine</span></div>
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg><span>Easy Returns</span></div>
                <div class="ph-trust-item"><svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg><span>Secure Checkout</span></div>
            </div>

            <?php else: ?>
            <!-- Price on Request / B2B Quote Box -->
            <div class="ph-quote-request-box">
                <div class="ph-quote-header">
                    <span class="ph-quote-badge">Corporate & B2B</span>
                    <div class="ph-quote-title">Price on Request</div>
                    <div class="ph-quote-subtitle">Contact our technical sales team for volume pricing.</div>
                </div>

                <div class="ph-quote-qty-section">
                    <label class="ph-quote-qty-label">Quantity Required</label>
                    <div class="ph-quote-qty-stretched">
                        <button type="button" id="ph-quote-qty-minus">−</button>
                        <input type="number" id="ph-quote-qty-input" value="1" min="1" max="999">
                        <button type="button" id="ph-quote-qty-plus">+</button>
                    </div>
                </div>

                <div class="ph-quote-actions">
                    <button class="ph-quote-btn ph-quote-btn-primary"
                        onclick="openQuoteModal('<?php echo esc_js($product->get_name()); ?>', '<?php echo esc_js($product->get_sku() ?: 'N/A'); ?>')">
                        Request Official Quote
                    </button>
                    <button class="ph-quote-btn ph-quote-btn-whatsapp"
                        onclick="sendQuoteWhatsApp('<?php echo esc_attr($wa_number); ?>', '<?php echo esc_js($product->get_name()); ?>', '<?php echo esc_js($product->get_sku() ?: 'N/A'); ?>')">
                        <svg fill="currentColor" viewBox="0 0 24 24" width="20" height="20"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                        Inquire via WhatsApp
                    </button>
                </div>

                <div class="ph-quote-meta">
                    <div class="ph-quote-meta-item">
                        <span class="ph-quote-meta-label">Availability</span>
                        <span class="ph-quote-meta-value"><span class="ph-stock-dot"></span><?php echo $product->is_in_stock() ? 'In Stock (UAE)' : 'Out of Stock'; ?></span>
                    </div>
                    <div class="ph-quote-meta-item">
                        <span class="ph-quote-meta-label">Supplier</span>
                        <span class="ph-quote-meta-value">PileHead Store</span>
                    </div>
                </div>

                <div class="ph-quote-trust">
                    <div class="ph-quote-trust-item"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>Secure Portal</div>
                    <div class="ph-quote-trust-item"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>B2B Terms</div>
                    <div class="ph-quote-trust-item"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>Fast Dispatch</div>
                </div>
            </div>
            <?php endif; ?>

            <div class="ph-buybox-divider"></div>

            <?php if ($price > 0): ?>
            <div>
                <div class="ph-bnpl-title">Buy Now, Pay Later</div>
                <div class="ph-bnpl-cards">
                    <?php
                    $installment   = $price > 0 ? number_format($price / 4, 2) : '0.00';
                    $bnpl_providers = array(
                        array('name' => 'Tabby',  'logo' => 'https://cdn.tabby.ai/assets/tabby-badge.png'),
                        array('name' => 'Tamara', 'logo' => 'https://cdn.tamara.co/assets/tamara-logo.png'),
                    );
                    foreach ($bnpl_providers as $bnpl):
                    ?>
                    <div class="ph-bnpl-card">
                        <div class="ph-bnpl-header">
                            <img src="<?php echo esc_url($bnpl['logo']); ?>" alt="<?php echo esc_attr($bnpl['name']); ?>" class="ph-bnpl-logo" onerror="this.style.display='none';this.nextElementSibling.style.display='block';">
                            <strong style="display:none;font-size:13px;"><?php echo esc_html($bnpl['name']); ?></strong>
                            <div>
                                <div class="ph-bnpl-amount">AED <?php echo $installment; ?></div>
                                <div class="ph-bnpl-per">/ month × 4</div>
                            </div>
                        </div>
                        <div class="ph-bnpl-dots">
                            <?php for ($d = 0; $d < 4; $d++): ?>
                            <div class="ph-dot" style="background:<?php echo $d === 0 ? 'var(--amber)' : 'var(--border)'; ?>;"></div>
                            <?php if ($d < 3): ?><div class="ph-dot-line"></div><?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <div class="ph-bnpl-timeline"><span>Today</span><span>Month 2</span><span>Month 3</span><span>Month 4</span></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div><!-- /ph-buybox -->

    </div><!-- /ph-product-grid -->

    <!-- ══ Sticky tab nav bar ══ -->
    <div class="ph-top-nav-bar" id="ph-top-nav-bar">
        <div class="ph-top-nav-inner">
            <span class="ph-top-nav-link active" data-target="tab-overview">Overview</span>
            <span class="ph-top-nav-link" data-target="tab-features">Features</span>
            <span class="ph-top-nav-link" data-target="tab-specifications">Specifications</span>
            <span class="ph-top-nav-link" data-target="tab-applications">Applications</span>
            <span class="ph-top-nav-link" data-target="tab-faqs">FAQs</span>
            <span class="ph-top-nav-link" data-target="tab-reviews">Reviews</span>
        </div>
    </div>

    <!-- ══ Tabs section ══ -->
    <div class="ph-tabs-section" id="ph-tabs-section">
        <div class="ph-tabs-nav">
            <div class="ph-tab-link active" data-tab="tab-overview">Overview</div>
            <div class="ph-tab-link" data-tab="tab-features">Features &amp; Benefits</div>
            <div class="ph-tab-link" data-tab="tab-specifications">Specifications</div>
            <div class="ph-tab-link" data-tab="tab-applications">Applications</div>
            <div class="ph-tab-link" data-tab="tab-faqs">FAQs</div>
            <div class="ph-tab-link" data-tab="tab-reviews">Reviews</div>
            <div class="ph-tab-link" data-tab="tab-delivery">Delivery Info</div>
        </div>

        <div class="ph-tab-pane active" id="tab-overview">
            <?php
            $overview_html = get_post_meta($product_id, 'ph_tab_description_html', true);
            if ($overview_html) {
                echo wp_kses_post($overview_html);
            } elseif ($product->get_description()) {
                echo wp_kses_post($product->get_description());
            } else {
                echo '<p>Full product description coming soon.</p>';
            }
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-features">
            <?php
            $features_html = get_post_meta($product_id, 'ph_tab_benefits_html', true)
                          ?: get_post_meta($product_id, '_features_benefits', true);
            echo $features_html ? wp_kses_post($features_html) : '<p>Features information coming soon.</p>';
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-specifications">
            <?php
            $ai_specs = get_post_meta($product_id, 'ph_tab_specifications_html', true);
            if ($ai_specs) {
                echo wp_kses_post($ai_specs);
            } else {
                $attributes = $product->get_attributes();
                if (!empty($attributes)) {
                    echo '<table class="ph-specs-table"><tbody>';
                    foreach ($attributes as $attribute) {
                        if (!$attribute->get_visible()) continue;
                        $attr_label  = wc_attribute_label($attribute->get_name());
                        $attr_values = implode(', ', wc_get_product_terms($product_id, $attribute->get_name(), array('fields' => 'names')));
                        if (empty($attr_values)) $attr_values = implode(', ', $attribute->get_options());
                        echo '<tr><th>' . esc_html($attr_label) . '</th><td>' . esc_html($attr_values) . '</td></tr>';
                    }
                    echo '</tbody></table>';
                } else {
                    echo '<p>Specifications coming soon.</p>';
                }
            }
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-applications">
            <?php
            $app_html = get_post_meta($product_id, 'ph_tab_application_html', true)
                     ?: get_post_meta($product_id, '_application_area', true);
            echo $app_html ? wp_kses_post($app_html) : '<p>Application information coming soon.</p>';
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-faqs">
            <?php
            $faqs_html = get_post_meta($product_id, 'ph_tab_faqs_html', true);
            echo $faqs_html ? wp_kses_post($faqs_html) : '<p>FAQs coming soon.</p>';
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-reviews">
            <?php
            if (comments_open($product_id)) {
                comments_template();
            } else {
                echo '<p>Reviews are currently disabled for this product.</p>';
            }
            ?>
        </div>

        <div class="ph-tab-pane" id="tab-delivery">
            <h3 style="margin-bottom:16px;font-family:var(--font-display);">Delivery &amp; Returns — UAE</h3>
            <table class="ph-specs-table">
                <tbody>
                    <tr><th>🚀 Express Delivery</th><td>Same Day within 3 hours (Abu Dhabi &amp; Dubai)</td></tr>
                    <tr><th>🚚 Standard Delivery</th><td>Next Day, Before 10 PM · All 7 Emirates</td></tr>
                    <tr><th>💰 Free Delivery</th><td>On orders above AED 200</td></tr>
                    <tr><th>📦 Returns</th><td>14-day hassle-free returns on unopened items</td></tr>
                    <tr><th>🏪 Dispatch</th><td>From our Dubai warehouse</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ══ Related Products ══ -->
    <?php if (!empty($related_ids)): ?>
    <div class="ph-related-section" id="ph-related-section">
        <div class="ph-related-header">
            <h2>Similar Products</h2>
            <div class="ph-related-nav">
                <span class="ph-related-counter" id="ph-related-counter">1–<?php echo min(6, count($related_ids)); ?> of <?php echo count($related_ids); ?></span>
                <button class="ph-related-nav-btn" id="ph-related-prev" disabled aria-label="Previous">
                    <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
                </button>
                <button class="ph-related-nav-btn" id="ph-related-next" aria-label="Next" <?php echo count($related_ids) <= 6 ? 'disabled' : ''; ?>>
                    <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
                </button>
            </div>
        </div>
        <div class="ph-related-carousel-wrap">
            <div class="ph-related-track" id="ph-related-track">
                <?php
                foreach ($related_ids as $related_id):
                    $rp = wc_get_product($related_id);
                    if (!$rp || !$rp->is_visible()) continue;
                    $rel_price     = $rp->get_price();
                    $rel_img_id    = $rp->get_image_id();
                    $rel_img_src   = $rel_img_id ? wp_get_attachment_image_url($rel_img_id, 'woocommerce_thumbnail') : wc_placeholder_img_src();
                    $rel_img_alt   = $rel_img_id ? (get_post_meta($rel_img_id, '_wp_attachment_image_alt', true) ?: $rp->get_name()) : $rp->get_name();
                    $rel_permalink = get_permalink($related_id);
                    $rel_brand     = '';
                    $rel_bt        = get_the_terms($related_id, 'product_brand');
                    if ($rel_bt && !is_wp_error($rel_bt)) $rel_brand = $rel_bt[0]->name;
                    if (empty($rel_brand)) { $rba = $rp->get_attribute('pa_brand'); if ($rba) $rel_brand = $rba; }
                ?>
                <a href="<?php echo esc_url($rel_permalink); ?>" class="ph-related-card">
                    <div class="ph-related-img-wrap">
                        <img src="<?php echo esc_url($rel_img_src); ?>" alt="<?php echo esc_attr($rel_img_alt); ?>" class="ph-related-img" loading="lazy">
                    </div>
                    <div class="ph-related-card-body">
                        <?php if ($rel_brand): ?><div class="ph-related-card-brand"><?php echo esc_html($rel_brand); ?></div><?php endif; ?>
                        <div class="ph-related-card-title"><?php echo esc_html($rp->get_name()); ?></div>
                        <?php if ((float)$rel_price > 0): ?>
                        <div class="ph-related-card-price">AED <?php echo number_format((float)$rel_price, 2); ?></div>
                        <?php else: ?>
                        <div class="ph-related-card-price" style="color:var(--stone);font-size:12px;">Get Price →</div>
                        <?php endif; ?>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div><!-- /ph-page -->

<!-- ══ Sticky bottom bar ══ -->
<div class="ph-sticky-bottom" id="ph-sticky-bottom">
    <div class="ph-sticky-bottom-inner">
        <?php if ($post_thumbnail_id): ?>
        <img src="<?php echo esc_url(wp_get_attachment_image_url($post_thumbnail_id, 'thumbnail')); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="ph-sticky-product-thumb">
        <?php endif; ?>
        <div>
            <div class="ph-sticky-name"><?php echo esc_html($product->get_name()); ?></div>
            <div class="ph-sticky-price">
                <?php if ($price > 0): ?>
                <img src="https://www.pilehead.com/wp-content/uploads/2025/10/uae-dirham-symbol.svg" alt="AED" style="height:12px;">
                <span id="ph-sticky-price-val"><?php echo number_format($price, 2); ?></span>
                <?php else: ?>
                <span style="font-size:12px;color:var(--stone);font-weight:600;">Price on Request</span>
                <?php endif; ?>
            </div>
        </div>
        <?php if ($price > 0): ?>
        <button class="ph-sticky-atc" id="ph-sticky-atc"
            data-product-id="<?php echo $product_id; ?>"
            <?php echo !$product->is_in_stock() ? 'disabled' : ''; ?>>
            Add to Cart
        </button>
        <?php else: ?>
        <a href="<?php echo esc_url($wa_url); ?>" class="ph-sticky-atc"
           style="background:#25D366;text-decoration:none;display:flex;align-items:center;gap:6px;margin-left:auto;"
           target="_blank" rel="noopener noreferrer">
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
            WhatsApp
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- ══ Delivery Modal ══ -->
<div id="deliveryModal" class="ph-modal-overlay hidden">
    <div class="ph-modal-box">
        <div class="ph-modal-header">
            <h3 id="modalTitle">Delivery Details</h3>
            <button class="ph-modal-close" onclick="closeDeliveryModal()">✕</button>
        </div>
        <div class="ph-modal-content">
            <div id="modalBody">
                <p><strong>Charges are based on:</strong></p>
                <ul>
                    <li>Distance to your location</li>
                    <li>Type of pickup/delivery</li>
                    <li>Order weight &amp; size</li>
                    <li>Delivery time slot selected</li>
                </ul>
                <p style="margin-top:15px;font-size:13px;color:#666;">The final delivery charge will be calculated based on your delivery address and selected options at checkout.</p>
            </div>
        </div>
        <div class="ph-modal-footer">
            <button class="ph-modal-btn" onclick="closeDeliveryModal()">Close</button>
        </div>
    </div>
</div>

<!-- ══ Quote Modal ══ -->
<div class="ph-quote-modal-overlay" id="quoteModal">
    <div class="ph-quote-modal-content">
        <button class="ph-quote-modal-close" onclick="closeQuoteModal()">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
        <div id="quoteFormWrapper">
            <h3 class="ph-quote-modal-title">Request a Quote</h3>
            <p class="ph-quote-modal-desc">Please provide your details. A sales engineer will contact you with pricing for <span id="modalQtyDisplay" style="font-weight:700;">1</span> unit(s) of <strong id="modalProductName"></strong>.</p>
            <form id="quoteForm" onsubmit="submitQuoteForm(event)">
                <input type="hidden" id="quoteProductName" name="product_name">
                <input type="hidden" id="quoteProductSku"  name="product_sku">
                <input type="hidden" id="quoteQty"         name="quantity">
                <div class="ph-quote-form-group"><label class="ph-quote-form-label">Full Name *</label><input type="text"  class="ph-quote-form-input" name="full_name"    required placeholder="John Doe"></div>
                <div class="ph-quote-form-group"><label class="ph-quote-form-label">Company Name</label><input type="text"  class="ph-quote-form-input" name="company_name" placeholder="Acme Corp LLC"></div>
                <div class="ph-quote-form-group"><label class="ph-quote-form-label">Work Email *</label><input type="email" class="ph-quote-form-input" name="email"        required placeholder="john@company.com"></div>
                <div class="ph-quote-form-group"><label class="ph-quote-form-label">Phone Number *</label><input type="tel"   class="ph-quote-form-input" name="phone"        required placeholder="+971 50 123 4567"></div>
                <button type="submit" class="ph-quote-btn ph-quote-btn-primary" style="margin-top:16px;width:100%;">Submit Request</button>
            </form>
        </div>
        <div class="ph-quote-success-state" id="successState">
            <div class="ph-quote-success-icon"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg></div>
            <h3 class="ph-quote-modal-title">Request Received</h3>
            <p class="ph-quote-modal-desc">Thank you. Our B2B sales team has received your inquiry and will respond shortly.</p>
            <button class="ph-quote-btn ph-quote-btn-primary" onclick="closeQuoteModal()">Close Window</button>
        </div>
    </div>
</div>

<!-- ══ PDF Preview Modal ══ -->
<div class="ph-pdf-modal-overlay" id="pdfModalOverlay">
    <div class="ph-pdf-modal-content">
        <div class="ph-pdf-modal-header">
            <div class="ph-pdf-modal-title">
                <div class="ph-file-ext">PDF</div>
                <h3 id="pdfModalTitle">Document Preview</h3>
            </div>
            <button class="ph-pdf-modal-close" onclick="closePdfPreview()">
                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="ph-docs-list" id="pdfDocsList" style="display:none;">
            <div class="ph-docs-list-header">Included Documents:</div>
            <div class="ph-docs-tabs" id="pdfDocsTabs"></div>
        </div>
        <iframe id="pdfViewerFrame" class="ph-pdf-viewer-frame" src="" type="application/pdf"></iframe>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
<?php
    } // end while
} // end have_posts
get_footer('shop');
